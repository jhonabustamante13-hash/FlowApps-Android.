# FlowApps Android

Seis proyectos Android independientes para EventFlow, Countdown, WordFlow, GalleryX, MusicFlow y TaskFlow. Cada carpeta se abre por separado en Android Studio. Compatibilidad configurada con targetSdk 30 (Android 11) y minSdk 23.

Para cada app: abrir su carpeta en Android Studio, esperar la sincronización de Gradle y elegir Build > Build APK(s).
