# EventFlow

Proyecto Android independiente. Compatible con Android 6.0 o superior; probado para compilar con SDK 33 y target Android 11 (API 30).

Abrir esta carpeta en Android Studio y compilar con Build > Build APK(s).
